
# CapBLE Link Module

This module simulates BLE transfer of CapToken between CapDevice (Sender) and CapReader (Receiver).
Note: Native BLE advertising is limited in Flutter. May require platform channels or Android/iOS-specific extensions for full production support.
