
import 'dart:convert';
import 'package:flutter_blue/flutter_blue.dart';

class CapBLEReceiver {
  void listenForTokens() {
    FlutterBlue.instance.scan(timeout: Duration(seconds: 10)).listen((scanResult) {
      final String payload = utf8.decode(scanResult.advertisementData.serviceData.values.first);
      print("Received CapToken: \$payload");
      // Hier: Übergabe an CapValidator
    });
  }
}
