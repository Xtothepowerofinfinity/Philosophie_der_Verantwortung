
import 'dart:convert';
import 'package:flutter_blue/flutter_blue.dart';

class CapBLESender {
  final String capTokenJson;

  CapBLESender(this.capTokenJson);

  void startBroadcast() {
    // Simuliertes BLE-Broadcasting via Advertisements (Flutter limitation note)
    // In echten Geräten evtl. via Android-Bluetooth-LowEnergy direkt
    print("Broadcasting CapToken: \$capTokenJson");
    // NOTE: BLE broadcasting über Flutter derzeit eingeschränkt
  }
}
