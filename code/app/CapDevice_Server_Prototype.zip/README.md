# CapDevice Server Prototype
Flask-based mock API for feedback and cap authorization.