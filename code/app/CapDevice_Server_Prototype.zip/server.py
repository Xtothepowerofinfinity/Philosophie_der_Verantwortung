
from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)

cap_data = {}
feedback_log = []

@app.route("/feedback/submit", methods=["POST"])
def submit_feedback():
    data = request.json
    feedback_log.append(data)
    return jsonify({"status": "received", "capImpact": "pending_evaluation"})

@app.route("/cap/<wallet>", methods=["GET"])
def get_cap(wallet):
    return jsonify(cap_data.get(wallet, {
        "wallet": wallet,
        "cap_solo": 0,
        "cap_team": 0,
        "cap_potential": 0,
        "role": "unknown",
        "last_feedback": None
    }))

@app.route("/cap/authorize", methods=["POST"])
def authorize():
    data = request.json
    return jsonify({
        "capToken": {
            "wallet": data["wallet"],
            "scope": data["requested_scope"],
            "cap_level": 91,
            "valid_until": int(datetime.now().timestamp()) + 3600,
            "signature": "0xFAKE_SIGNATURE"
        }
    })

@app.route("/identity/link", methods=["POST"])
def link_identity():
    return jsonify({"status": "linked", "valid_until": int(datetime.now().timestamp()) + 86400})

if __name__ == "__main__":
    app.run(debug=True)
