# X^∞ CapDevice App
Flutter-based prototype for CapNFT identity, feedback, and authorization.