
import 'package:flutter/material.dart';

void main() {
  runApp(CapDeviceApp());
}

class CapDeviceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'X∞ CapDevice',
      home: Scaffold(
        appBar: AppBar(title: const Text('CapDevice Dashboard')),
        body: const Center(
          child: Text('Welcome to the CapDevice PoC. Identity. Feedback. Authorization.'),
        ),
      ),
    );
  }
}
