# CapReader AuditLog Module
Stores all token verification attempts with outcome and timestamp.