
import 'dart:convert';
import 'dart:io';

class AuditLogger {
  final String logFilePath = "audit_log.json";

  void logAccessResult(Map<String, dynamic> token, bool granted) {
    final entry = {
      "wallet": token["wallet"],
      "role": token["role"],
      "cap_level": token["cap_level"],
      "scope": token["scope"],
      "valid_until": token["valid_until"],
      "granted": granted,
      "timestamp": DateTime.now().toIso8601String()
    };

    final file = File(logFilePath);
    List<dynamic> existing = [];

    if (file.existsSync()) {
      existing = json.decode(file.readAsStringSync());
    }

    existing.add(entry);
    file.writeAsStringSync(json.encode(existing), flush: true);
  }
}
