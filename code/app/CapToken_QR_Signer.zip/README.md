# CapToken QR Signer
Generates signed CapTokens and renders them as QR codes.