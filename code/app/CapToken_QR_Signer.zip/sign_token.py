
import qrcode
import json
from datetime import datetime, timedelta
from eth_account import Account

# Beispielhafte Wallet (testweise, nicht produktiv)
PRIVATE_KEY = "0xabc123...FAKE"

def generate_token(wallet, role, cap_level):
    payload = {
        "wallet": wallet,
        "role": role,
        "cap_level": cap_level,
        "valid_until": int((datetime.utcnow() + timedelta(hours=1)).timestamp())
    }
    token_str = json.dumps(payload)
    signed = Account.sign_message(token_str.encode(), private_key=PRIVATE_KEY)

    token = {
        "data": payload,
        "signature": signed.signature.hex()
    }

    return token

def generate_qr(token_obj, output_file="cap_token_qr.png"):
    qr = qrcode.make(json.dumps(token_obj))
    qr.save(output_file)
    print(f"QR saved to {output_file}")

# Beispiel-Nutzung
if __name__ == "__main__":
    token = generate_token("0xDEADBEEF", "Wächter", 87)
    generate_qr(token)
