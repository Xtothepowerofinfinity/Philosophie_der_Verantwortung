
import 'dart:convert';
import 'dart:io';

class CapValidator {
  bool validateCapToken(Map<String, dynamic> token) {
    final int now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    if (token["valid_until"] < now) return false;
    return true;
  }

  bool isLocallySeen(String wallet) {
    final file = File("seen_devices_log.json");
    if (!file.existsSync()) return false;
    final entries = json.decode(file.readAsStringSync());
    return entries.any((entry) => entry["mac"] == wallet);
  }

  bool isMeshConfirmed(String wallet) {
    final file = File("synced_seen_log.json");
    if (!file.existsSync()) return false;
    final entries = json.decode(file.readAsStringSync());
    return entries.any((entry) => entry["mac"] == wallet);
  }
}
