
# X^∞ CapGate Mesh Protocol

## Purpose:
- Share seen WiFi/BLE presence data between CapGate nodes.
- Enable cross-checks for validation, movement, ghosting, etc.

## Files:
- seen_devices_log.json – local presence
- synced_seen_log.json – remote presence
- audit_log.json – all validation results

## Flow:
1. Gate A scans BLE/WiFi
2. Gate B scans BLE/WiFi
3. Sync via exportSeenLog() and receiveSyncData()
4. Token validation checks both sources

Recommended sync: every 15–60 seconds depending on zone density.
