
import 'dart:convert';
import 'dart:io';

class GateSync {
  final String syncFile = "synced_seen_log.json";

  void receiveSyncData(String jsonString) {
    final incoming = json.decode(jsonString);
    final file = File(syncFile);
    List<dynamic> existing = [];

    if (file.existsSync()) {
      existing = json.decode(file.readAsStringSync());
    }

    existing.addAll(incoming);
    file.writeAsStringSync(json.encode(existing), flush: true);
  }

  String exportSeenLog() {
    final file = File("seen_devices_log.json");
    if (!file.existsSync()) return "[]";
    return file.readAsStringSync();
  }
}
