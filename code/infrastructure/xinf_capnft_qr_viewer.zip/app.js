
// Beispielhafter QR-Wallet-Connect mit ethers.js und WalletConnect
async function connectWallet() {
  const provider = new WalletConnectProvider.default({
    rpc: {
      5: "https://goerli.infura.io/v3/YOUR_INFURA_KEY"
    },
    chainId: 5
  });

  await provider.enable();
  const ethersProvider = new ethers.providers.Web3Provider(provider);
  const signer = ethersProvider.getSigner();
  const address = await signer.getAddress();

  document.getElementById("output").innerText = "Connected: " + address;

  // hier könnte der CapNFT Contract abgefragt werden
}
